Keystore Renca NFC

Generar keystore para Google play store: 
command MAC: sudo keytool -genkey -v -keystore rencanfc.keystore -alias miltonrencanfc -keyalg RSA 
-keysize 2048 -validity 10000

Alias: miltonrencanfc
upload keystore: rencanfc.keystore 
password: renca2019

Warning al generar keystore:
Warning:

El almacén de claves JKS utiliza un formato propietario. Se recomienda migrar a PKCS12, que es un 
formato estándar del sector que utiliza "keytool -importkeystore -srckeystore rencanfc.keystore 
-destkeystore rencanfc.keystore -deststoretype pkcs12”